# Shadertoy2Threejs

![Result](https://cdn-images-1.medium.com/max/1600/1*yYYiOx6-76my-WZbUAOznQ.png)

Example source code for this Medium article:
[deutsche Version](https://medium.com/@markus.neuy/postprocessing-shader-mit-shadertoy-und-threejs-8164600c6c76) / [english version](https://medium.com/@dirkk/converting-shaders-from-shadertoy-to-threejs-fe17480ed5c6)
