# Tutoroos

__Name: Kunsh, Elaine, Abby, Josh, Sam

__Computing ID: bca2nk, zzb2rf, hse2dq, jsy3zp, sdh7ksu

# Sources

https://getbootstrap.com/docs/4.0/
http://svgicons.sparkk.fr/
https://www.bootdey.com/snippets/view/profile-with-data-and-skills
